module.exports = {
  lintOnSave: false,
  configureWebpack: {
    entry: './src/main.js'
  }
}
